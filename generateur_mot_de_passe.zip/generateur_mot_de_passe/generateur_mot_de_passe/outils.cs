﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetMdp // Espace de nom
{
    static class outils
    {
        public static int DemanderNombrePositifNonNul(string question)
        {
            int nombreInt = DemanderNombre(question);
            if (nombreInt > 0)
            {
                // valide
                return nombreInt;
            }
            // Sinon, pas valide
            Console.WriteLine("ERREUR : Le nombre doit etre superieur a 0");

            return DemanderNombrePositifNonNul(question);
            // return DemanderNombreEntre(question, 1, int.MaxValue, "ERREUR : Le nombre doit etre positif et non nul";
        }
        public static int DemanderNombreEntre(string question, int min, int max, string messageErreurPersonnalise = null)
        {
            while (true)
            {
                int nombreInt = DemanderNombre(question);
                if ((nombreInt >= min) || (nombreInt <= max))
                {
                    // valide
                    return nombreInt;
                }
                if (messageErreurPersonnalise == "")
                {
                    // Sinon, pas valide
                    Console.WriteLine("\nERREUR : Le nombre doit etre compris entre " + min + " et " + max);
                }
                else
                    Console.WriteLine(messageErreurPersonnalise);


                // return DemanderNombreEntre(question, min, max); // Fonction recursive (On peut l'appliquer sans la boucle while)
            }

        }

        public static int DemanderNombre(string question)
        {
            while (true)
            {
                Console.Write(question);
                string reponse = Console.ReadLine();
                try
                {
                    int reponseInt = int.Parse(reponse);
                    return reponseInt;
                }
                catch
                {

                    Console.WriteLine("ERREUR : Vous devez rentrer un nombre");
                }
            }

        }
    }
}
